import './style/index.scss';


function sayHello(){
    /*eslint-disable no-console */
    console.log("Allo! We are all set!");
    console.log("Arrow functions are working");
};


const editDom = () => {
  const main = document.getElementById('main');
  main.innerHTML = 'Hello World! ';

  const root = document.getElementById('root');
  root ? root.innerHTML = 'Hello World! ':null;
};

var  Rating = require('rating-gen');
var $ = require('../node_modules/jquery/dist/jquery');

var rating = new Rating({
    field: $('.rating-container'),
    defaultRating: 3,
    onSelect: function(rating) {
        alert(rating);
    }
}); 
rating.set(3);

sayHello();
editDom();